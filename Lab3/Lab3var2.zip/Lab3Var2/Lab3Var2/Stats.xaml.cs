﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab3Var2
{
    /// <summary>
    /// Логика взаимодействия для Stats.xaml
    /// </summary>
    public partial class Stats : Window
    {
        double Date;
        int dn ;
        int inpr ;
        int ex ;
        public Stats(double date,int _dn,int _inpr,int _ex)
        {
            InitializeComponent();
            this.Date = date;
            this.dn = _dn;
            this.inpr = _inpr;
            this.ex = _ex;
            countTime.Content = $"Среднее время выполнения заявки: {Date:F2} минут";
            Donebox.Content = $"Выполненые заявки: {dn} штук.";
            inprBox.Content = $"Заявки в процессе: {inpr} штук.";
            exBox.Content = $"Не обработанные заявки: {ex} штук.";
        }
    }
}
