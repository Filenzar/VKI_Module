﻿using System.ComponentModel;

namespace Lab3Var2.ContextLibrary.Entities
{
    /// <summary>
    /// Сущность "Заявка"
    /// </summary>
    public class Request : INotifyPropertyChanged
    {
        private int _number;
        public DateTime AddedDate { get; set; }
        public DateTime _endDate;
        private Type _productType;
        private string _model;
        private string _description;
        private string _customerFullName;
        private string _customerPhone;
        private RequestStatus _status;
        private string _master;

        public int Number
        {
            get => _number;
            set
            {
                _number = value;
                OnPropertyChanged(nameof(Number));
            }
        }
        public string Master
        {
            get => _master;
            set
            {
                _master = value;
                OnPropertyChanged(nameof(Master));
            }
        }
        public DateTime EndDate
        {
            get => _endDate;
            set
            {
                _endDate = value;
                OnPropertyChanged(nameof(EndDate));
            }
        }
        public Type ProductType
        {
            get => _productType;
            set
            {
                _productType = value;
                OnPropertyChanged(nameof(ProductType));
            }
        }
        public string Model
        {
            get => _model;
            set
            {
                _model = value;
                OnPropertyChanged(nameof(Model));
            }
        }
        public string Description
        {
            get => _description;
            set
            {
                _description = value;
                OnPropertyChanged(nameof(_description));
            }
        }

        public string CustomerFullName
        {
            get => _customerFullName;
            set
            {
                _customerFullName = value;
                OnPropertyChanged(nameof(CustomerFullName));
            }
        }

        public string CustomerPhone
        {
            get => _customerPhone;
            set
            {
                _customerPhone = value;
                OnPropertyChanged(nameof(CustomerPhone));
            }
        }

        public RequestStatus Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
