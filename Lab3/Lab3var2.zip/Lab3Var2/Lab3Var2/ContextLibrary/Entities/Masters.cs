﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Var2.ContextLibrary.Entities
{
    public class Masters : INotifyPropertyChanged
    {
        private int _number;
        private string _masterFullName;

        public int Number
        {
            get => _number;
            set
            {
                _number = value;
                OnPropertyChanged(nameof(Number));
            }
        }


        public string MasterFullName
        {
            get => _masterFullName;
            set
            {
                _masterFullName = value;
                OnPropertyChanged(nameof(_masterFullName));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
