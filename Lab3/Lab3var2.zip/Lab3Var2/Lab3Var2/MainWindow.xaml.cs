﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Lab3Var2.ContextLibrary.Entities;
using Lab3Var2.ContextLibrary;
using System.Collections.ObjectModel;

namespace Lab3Var2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml   
    /// </summary>
    public partial class MainWindow : Window
    {
        public int count = ApplicationContext.GetRequests().Count;
        private ObservableCollection<Request> _allRequests;
        private ObservableCollection<Masters> _allMasters;
        public MainWindow()
        {
            InitializeComponent();
            _allRequests = ContextLibrary.ApplicationContext.GetRequests();
            _allMasters = ContextLibrary.ApplicationContext.GetMasters();
            RequestsListView.ItemsSource = _allRequests;
            ProductTypeComboBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.Type));
            MastersTypeComboBox.ItemsSource = _allMasters;
            MastersTypeComboBox.DisplayMemberPath = "MasterFullName";
            MastersTypeComboBox.SelectedValuePath = "MasterFullName";
            StatusBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.RequestStatus));
            ProductTypeComboBox.SelectedIndex = 0;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now, ProductType = ContextLibrary.Entities.Type.Fridge, Model = "Model A", Description = "Description A", CustomerFullName = "John Doe", CustomerPhone = "123-456-7890", Status = RequestStatus.InProgress });
            ApplicationContext.AddMaster(new Masters { Number = count + 1, MasterFullName = "John Doe" });
            count++;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now, ProductType = ContextLibrary.Entities.Type.Phone, Model = "Model B", Description = "Description B", CustomerFullName = "Jane Smith", CustomerPhone = "098-765-4321", Status = RequestStatus.InProgress });
            ApplicationContext.AddMaster(new Masters { Number = count + 1, MasterFullName = "Hto eto" });
            count++;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now, ProductType = ContextLibrary.Entities.Type.TV, Model = "Model C", Description = "Description C", CustomerFullName = "Alice Johnson", CustomerPhone = "555-555-5555", Status = RequestStatus.Expectation });
            count++;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now, ProductType = ContextLibrary.Entities.Type.Fridge, Model = "Model A", Description = "Description A", CustomerFullName = "John Doe", CustomerPhone = "123-456-7890", Status = RequestStatus.InProgress });
            count++;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now, ProductType = ContextLibrary.Entities.Type.TV, Model = "Model B", Description = "Description B", CustomerFullName = "Jane Smith", CustomerPhone = "098-765-4321", Status = RequestStatus.InProgress });
            count++;
            ApplicationContext.AddRequest(new Request { Number = count + 1, AddedDate = DateTime.Now,  ProductType = ContextLibrary.Entities.Type.WashingMachine, Model = "Model C", Description = "Description C", CustomerFullName = "Alice Johnson", CustomerPhone = "555-555-5555", Status = RequestStatus.InProgress });
            count++;
        }
        
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newRequest = new Request
                {
                    Number = count + 1 , // Генерация номера заказа
                    AddedDate = DateTime.Now,
                    ProductType = (ContextLibrary.Entities.Type)ProductTypeComboBox.SelectedItem,
                    Master= MastersTypeComboBox.SelectedValue.ToString(),
                    Model = Model.Text,
                    Description = Desc.Text,
                    CustomerFullName = CustomerNameTextBox.Text,
                    CustomerPhone = CustomerPhoneTextBox.Text,
                    Status = RequestStatus.Expectation // Начальный статус
                };

                ApplicationContext.AddRequest(newRequest);
                MessageBox.Show("Заказ успешно добавлен!");
                count++;
                Model.Text = null;
                Desc.Text = null;
                CustomerNameTextBox.Text = null;
                CustomerPhoneTextBox.Text = null;
            }
            catch
            {
                MessageBox.Show("Неправельное заполнение", "Ошибка");
            }
        }
        private void EditOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var editOrderWindow = new EditRequestWindow(selectedRequest);
                editOrderWindow.ShowDialog();
            }
        }
        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить заказ?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    ApplicationContext.DeleteRequest(selectedRequest.Number);
                }
            }
        }
        private void searchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = search.Text;

            // Проверка, является ли введённый текст числом
            if (int.TryParse(filter, out int numberFilter))
            {
                // Фильтрация данных по номеру
                var filteredRequests = _allRequests
                    .Where(request => request.Number == numberFilter)
                    .ToList();

                // Обновление ItemsSource
                RequestsListView.ItemsSource = new ObservableCollection<Request>(filteredRequests);
            }
            else
            {
                // Если введённый текст не является числом, показываем все запросы
                RequestsListView.ItemsSource = _allRequests;
            }
        }
        private void JustButton_Click(object sender, RoutedEventArgs e)
        {
            double date = 0;
            int dn = 0;
            int inpr = 0;
            int ex = 0;
            foreach (Request selectedRequest in RequestsListView.Items)
            {
                if (selectedRequest.Status == RequestStatus.Done)date += (selectedRequest.EndDate - selectedRequest.AddedDate).TotalMinutes;
                if (selectedRequest.Status == RequestStatus.Done) dn++;
                if (selectedRequest.Status == RequestStatus.Expectation) ex++;
                if (selectedRequest.Status == RequestStatus.InProgress) inpr++;
            }
            var StatsWindow = new Stats(date,dn,ex,inpr);
            StatsWindow.ShowDialog();
        }
        private void TestButton_Click(object sender, RoutedEventArgs e)
        {
            if (MasterBox.Text.Length !=0)
            {
                ApplicationContext.AddMaster(new Masters { Number = count + 1, MasterFullName = MasterBox.Text });
                MessageBox.Show("Мастер успешно добавлен!");
            }
            else
            {
                MessageBox.Show("Поле не заполненно.");
            }

            }
        
    }
}