﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using AppBook.Forms;
using static System.Reflection.Metadata.BlobBuilder;


namespace AppBook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static MainWindow _instance;

        private User usercurrent = new User();
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        internal MainWindow(User _user)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);

            usercurrent = _user;
            NameUser.DataContext = usercurrent;
            if (usercurrent.ID_Type != 1)
            {
                AdmnButton.Visibility = Visibility.Collapsed;
                AdmnButton.IsEnabled = false;
            }
            LoadProducts();
        }
        internal static MainWindow GetInstance(User user)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new MainWindow(user);
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var books= await _unitOfWork.Books.GetAllAsync();
            foreach (var book in books)
            {
                book.Author = await _unitOfWork.Authors.GetByIdAsync((int)book.ID_Autor);
                book.Publishing = await _unitOfWork.Publishings.GetByIdAsync((int)book.ID_Publishing);
            }
            ProductListView.ItemsSource = books;
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            LoginUs login = new LoginUs();
            login.Show();
            this.Close();
        }
        private void Cart_Click(object sender, RoutedEventArgs e)
        {
            if (usercurrent.CurrentCart == null)
            {
                MessageBox.Show("В корзине ничего нет. Пожалуйста, добавте что-нибудь в корзину.");
            }
            else
            {
                Cart cart = Cart.GetInstance(usercurrent);
                cart.Show();
                this.Close();
            }
        }
        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            OrdersForm order = new OrdersForm(usercurrent);
            order.Show();
        }

        private async void AddCart_Click(object sender, RoutedEventArgs e)
        {
            

            Button clickedButton = sender as Button;
            if ((clickedButton != null) )
            {
                var idbook = clickedButton.Tag;
                var content = await _unitOfWork.ContentsOrders.GetAllAsync();
                var _filter1 = content.Where(b => b.ID_Order == usercurrent.CurrentCart);
                var _filter2 = _filter1.Any(b => b.ID_Book == (int)idbook);
                
                if (usercurrent.CurrentCart == null)
                {
                    await _serviceAdd.AddNewOrder(usercurrent.ID_User);
                }
                if (!_filter2)
                {
                    // Получаем значение Tag из кнопки
                    usercurrent = await _unitOfWork.Users.GetByIdAsync(usercurrent.ID_User);
                    var book = await _unitOfWork.Books.GetByIdAsync((int)idbook);
                    if (book.Copies > 0) 
                    {
                        book.Copies -= 1;
                        await _unitOfWork.Books.UpdateAsync(book);
                        await _unitOfWork.CompleteAsync();


                        await _serviceAdd.AddNewContent((int)usercurrent.CurrentCart, (int)idbook);
                        MessageBox.Show($"Книга {book.Name} добавлена в корзину");
                        LoadProducts();
                    }
                    else
                    {
                        MessageBox.Show("Этой книги больше нет в наличии");
                    }
                }
            }
        }
        private void UserButoon_Click(object sender, RoutedEventArgs e)
        {
            var user = UserForm.GetInstance(usercurrent);
            user.Show();
        }
        private void AdminButoon_Click(object sender, RoutedEventArgs e)
        {
            var adm =  AdminForm.GetInstance(usercurrent);
            adm.Show();
            this.Close();
        }


    }
}