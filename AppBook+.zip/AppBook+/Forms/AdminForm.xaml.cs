﻿using AppBook.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        private static AdminForm _instance;
        private User _usercurrent = new User();
        internal AdminForm(User user)
        {
            InitializeComponent();
            _usercurrent = user;
        }
        internal static AdminForm GetInstance(User user)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new AdminForm(user);
            }
            return _instance;
        }

        private void Book_Click(object sender, RoutedEventArgs e)
        {
            var book = AllBookForm.GetInstance();
            book.Show();

        }
        private void Order_Click(object sender, RoutedEventArgs e)
        {
            var order = AllOrdersForm.GetInstance();
            order.Show();

        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var main = MainWindow.GetInstance(_usercurrent);
            main.Show();
            this.Close();
        }

    }
}
