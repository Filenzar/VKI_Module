﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using AppBook.Model;
using System.ComponentModel;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для Cart.xaml
    /// </summary>
    
    public partial class Cart : Window, INotifyPropertyChanged
    {
        private static Cart _instance;
        private User _usercurrent;
        private readonly IUnitOfWork _unitOfWork;

        private decimal _totalPrice;

        internal Cart(User user) // Убедитесь, что User доступен
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _usercurrent = user;
            LoadProducts();
        }
        internal static Cart GetInstance(User user)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new Cart(user);
            }
            return _instance;
        }

        private async void LoadProducts()
        {
            var _filter = _usercurrent.CurrentCart;
            if (_filter != null)
            {
                var Order = await _unitOfWork.Orders.GetByIdAsync((int)_filter);
                var content = await _unitOfWork.ContentsOrders.GetAllAsync();
                var _filter2 = content.Where(b => b.ID_Order == (int)_filter);
                foreach (var cntt in _filter2)
                {
                    cntt.Book = await _unitOfWork.Books.GetByIdAsync((int)cntt.ID_Book);
                }

                ProductListView.ItemsSource = _filter2;
                Price.DataContext = this;
                //await _unitOfWork.CompleteAsync();
                UpdateTotalPrice();
            }
            
        }
        private async void MinButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {

                // Получаем значение Tag из кнопки
                var idContents = clickedButton.Tag;
                var Content = await _unitOfWork.ContentsOrders.GetByIdAsync((int)idContents);
                var book = await _unitOfWork.Books.GetByIdAsync((int)Content.ID_Book);
                if (Content.Count > 1) 
                {

                    Content.Count -= 1;
                    await _unitOfWork.ContentsOrders.UpdateAsync(Content);
                    await _unitOfWork.CompleteAsync();
                    book.Copies += 1;
                    await _unitOfWork.Books.UpdateAsync(book);
                    await _unitOfWork.CompleteAsync();
                    LoadProducts();
                    UpdateTotalPrice();
                }
                // Здесь вы можете использовать idContents для удаления или других операций
                //MessageBox.Show($"Удалить элемент с ID: {idContents}");
            }
        }
        private async void AddButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idContents = clickedButton.Tag;
                var Content = await _unitOfWork.ContentsOrders.GetByIdAsync((int)idContents);
                var book = await _unitOfWork.Books.GetByIdAsync((int)Content.ID_Book);
                if (Content.Count < 10 && book.Copies > 0)
                {
                    Content.Count += 1;
                    await _unitOfWork.ContentsOrders.UpdateAsync(Content);
                    await _unitOfWork.CompleteAsync();

                    book.Copies -= 1;
                    await _unitOfWork.Books.UpdateAsync(book);
                    await _unitOfWork.CompleteAsync();
                    LoadProducts();
                    UpdateTotalPrice();
                }
                else 
                {
                    MessageBox.Show("Книги больше нет в наличии");
                }
                // Здесь вы можете использовать idContents для удаления или других операций
                //MessageBox.Show($"Удалить элемент с ID: {idContents}");
            }
        }
        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idContents = clickedButton.Tag;
                var Content = await _unitOfWork.ContentsOrders.GetByIdAsync((int)idContents);
                var book = await _unitOfWork.Books.GetByIdAsync((int)Content.ID_Book);
                book.Copies += Content.Count;
                await _unitOfWork.Books.UpdateAsync(book);
                await _unitOfWork.CompleteAsync();

                await _unitOfWork.ContentsOrders.DeleteAsync((int)idContents);
                await _unitOfWork.CompleteAsync();
                LoadProducts();
                UpdateTotalPrice();
            }
        }
        private async void DeliveryButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            var Order = await _unitOfWork.Orders.GetByIdAsync((int)_usercurrent.CurrentCart);
            if ((clickedButton != null)&&(Price.Text!="0"))
            {
                if(Address.Text != "") 
                {
                    Order.Status = "В пути";
                    Order.DeliveryAddress = Address.Text;
                    Order.OrderPrice = _totalPrice;
                    await _unitOfWork.Orders.UpdateAsync(Order);

                    _usercurrent.CurrentCart = null;
                    await _unitOfWork.Users.UpdateAsync(_usercurrent);
                    await _unitOfWork.CompleteAsync();

                    MessageBox.Show($"Заказ оформлен");

                    var main = MainWindow.GetInstance(_usercurrent);
                    main.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Заполните все поля");
                }

            }
            else
            {
                MessageBox.Show("В вашей корзине ничего нет");
            }
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            var main =  MainWindow.GetInstance(_usercurrent);
            main.Show();
            this.Close();
        }





        public decimal TotalPrice
        {
            get { return _totalPrice; }
            set
            {
                if (_totalPrice != value)
                {
                    _totalPrice = value;
                    OnPropertyChanged(nameof(TotalPrice));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        private void UpdateTotalPrice()
        {
            TotalPrice = 0; // Сброс цены перед пересчетом

            var contents = ProductListView.ItemsSource as IEnumerable<ContentsOrder>; // Предполагается, что ваш источник данных - это IEnumerable<ContentOrder>

            if (contents != null)
            {
                foreach (var cntt in contents)
                {
                    TotalPrice += cntt.Book.Price * cntt.Count; // Пересчет общей цены
                }
            }
        }
    }
}
