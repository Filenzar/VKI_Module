﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace AppBook
{
    /// <summary>
    /// Логика взаимодействия для Registr.xaml
    /// </summary>
    public partial class Registr : Window
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        public Registr()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
        }
        private async void RegistrButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Button clickedButton = sender as Button;

                if (clickedButton != null)
                {
                    if (Name.Text != "" && Login.Text != "" && Password.Text != "" && Phone.Text != "" && Email.Text != "")
                    {
                        await _serviceAdd.AddNewUser(Name.Text, Phone.Text, Email.Text, Login.Text, Password.Text);
                        MessageBox.Show($"Пользователь {Name.Text} успешон зарегистрирован");
                        this.Close();
                    }
                    else 
                    { 
                        MessageBox.Show($"Заполните все поля"); 
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }

        }
    }
}
