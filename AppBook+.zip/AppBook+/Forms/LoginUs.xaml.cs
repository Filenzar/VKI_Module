﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace AppBook
{
    /// <summary>
    /// Логика взаимодействия для LoginUs.xaml
    /// </summary>
    public partial class LoginUs : Window
    {
        private readonly IUnitOfWork _unitOfWork;
        public LoginUs()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
        }
        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Button clickedButton = sender as Button;

                if (clickedButton != null)
                {
                    var Users = await _unitOfWork.Users.GetAllAsync();
                    var ouwer = Users.FirstOrDefault(b => b.Login.ToLower() == LoginBox.Text.Trim().ToLower() && b.Password.ToLower() == passwordBox.Password.Trim().ToLower());
                    if (ouwer != null)
                    {
                        
                        var main = new MainWindow(ouwer);
                        this.Close();
                        MessageBox.Show($"Добро пожаловать {ouwer.Name}", "Вход");
                        main.Show();
                    }
                    else
                    {
                        MessageBox.Show($"Неправельный логин или пароль", "Ошибка");
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка");
            }

        }
        private void RegButton_Click(object sender, RoutedEventArgs e)
        {
           
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                var reg = new Registr();
                //this.Close();
                reg.Show();
            }
        }
    }
}
