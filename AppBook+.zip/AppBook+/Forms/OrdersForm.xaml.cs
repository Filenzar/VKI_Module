﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using AppBook.Forms;


namespace AppBook
{
    /// <summary>
    /// Логика взаимодействия для OrdersForm.xaml
    /// </summary>
    public partial class OrdersForm : Window
    {
        private static OrdersForm _instance;
        private User _usercurrent;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        internal OrdersForm(User user)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
            _usercurrent = user;
            LoadProducts();
            

        }
        internal static OrdersForm GetInstance(User user)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new OrdersForm(user);
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var orders1 = await _unitOfWork.Orders.GetAllAsync();
            var filtered = orders1.Where(b => b.ID_User == _usercurrent.ID_User && b.ID_Order != _usercurrent.CurrentCart && b.Status=="Доставлено");
            OrdertListView.ItemsSource = filtered;

            var orders2 = await _unitOfWork.Orders.GetAllAsync();
            var filtered2 = orders2.Where(b => b.ID_User == _usercurrent.ID_User && b.ID_Order != _usercurrent.CurrentCart && b.Status != "Доставлено");
            OrdertDeliveredListView.ItemsSource = filtered2;
        }

        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idOrder = clickedButton.Tag;
                var info = new OrderInfo((int)idOrder);
                info.Show();
                // Здесь вы можете использовать idContents для удаления или других операций
                //MessageBox.Show($"Удалить элемент с ID: {idContents}");
            }
        }
    }
}
