﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using AppBook.Model;
using Azure;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для AddAutorForm.xaml
    /// </summary>
    public partial class AddAutorForm : Window
    {
        private static AddAutorForm _instance;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;

        public AddAutorForm()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
        }
        internal static AddAutorForm GetInstance()
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new AddAutorForm();
            }
            return _instance;
        }
        private async void AddBookButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (Name.Text != "")
                {
                    await _serviceAdd.AddNewAutor(Name.Text);
                    MessageBox.Show($"Автор успешно добавлен", "Добавление автора");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Пожалуйста, заполните все поля.");
                }

                //int selectedPubId = ComboBoxPublish.SelectedIndex;
                //MessageBox.Show($"ComboBoxAutors: {selectedAutorId} ComboBoxAutors: {selectedPubId}");
                //_serviceAdd.AddNewBook(Name.Text, (int)selectedAutorId,)

            }
        }
    }
}
