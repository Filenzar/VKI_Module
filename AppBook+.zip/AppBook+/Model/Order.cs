﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBook.Model
{
    class Order
    {
        [Key]
        public int ID_Order { get; set; }
        public int ID_User { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime Date { get; set; }
        public string Status { get; set; }
        public string DeliveryAddress { get; set; }
        public decimal? OrderPrice { get; set; }

        public User User { get; set; }
        public ICollection<ContentsOrder> ContentsOrders { get; set; }

        public ICollection<User> Users { get; set; }
    }
}
