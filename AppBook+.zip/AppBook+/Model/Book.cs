﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBook.Model
{
    class Book
    {
        [Key]
        public int ID_Book { get; set; }
        public string Name { get; set; }
        public int? ID_Autor { get; set; }
        public int? ID_Publishing { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Year { get; set; }
        public int Age { get; set; }
        public int Pages { get; set; }
        public int Copies { get; set; }

        public Autor Author { get; set; }
        public Publishing Publishing { get; set; }
        public ICollection<ContentsOrder> ContentsOrders { get; set; }
    }
}
