﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBook.Model
{
    class UserType
    {
        [Key]
        public int ID_Type { get; set; }
        public string Name { get; set; }
        public ICollection<User> Users { get; set; }
    }
}
