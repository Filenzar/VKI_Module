﻿using AppBook.Interface;
using AppBook.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBook.Class
{
    class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
            Authors = new GenericRepository<Autor>(_context);
            Books = new GenericRepository<Book>(_context);
            ContentsOrders = new GenericRepository<ContentsOrder>(_context);
            Orders = new GenericRepository<Order>(_context);
            Publishings = new GenericRepository<Publishing>(_context);
            Users = new GenericRepository<User>(_context);
            UserTypes = new GenericRepository<UserType>(_context);
        }

        public IGenericRepository<Autor> Authors { get; private set; }
        public IGenericRepository<Book> Books { get; private set; }
        public IGenericRepository<ContentsOrder> ContentsOrders { get; private set; }
        public IGenericRepository<Order> Orders { get; private set; }
        public IGenericRepository<Publishing> Publishings { get; private set; }
        public IGenericRepository<User> Users { get; private set; }
        public IGenericRepository<UserType> UserTypes { get; private set; }

        public async Task<int> CompleteAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
