﻿using AppBook.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace AppBook.Class
{
    class ServiceAdd
    {
        private readonly IUnitOfWork _unitOfWork;

        public ServiceAdd(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task AddNewBook(string name , int authorId, int publId, int price, int year, int age,int count,int page, string description = "Описание")
        {
            var book = new Book
            {
                Name = name,
                ID_Autor = authorId,
                ID_Publishing = publId,
                Price = price,
                Year = year,
                Age = age,
                Description = description,
                Copies = count,
                Pages = page
            };

            await _unitOfWork.Books.AddAsync(book);
            await _unitOfWork.CompleteAsync();
        }
        public async Task AddNewContent(int _ID_Order, int _ID_Book)
        {
            var content = new ContentsOrder
            {
                ID_Order = _ID_Order,
                ID_Book = _ID_Book,
                Count = 1
            };

            await _unitOfWork.ContentsOrders.AddAsync(content);
            await _unitOfWork.CompleteAsync();
        }
        public async Task AddNewUser(string _name, string _phoneNumber, string _email, string _login,string _password)
        {
            var user = new User
            {
                Name = _name,
                PhoneNumber = _phoneNumber,
                Email = _email,
                Login = _login,
                Password = _password,
                ID_Type = 2
            };

            await _unitOfWork.Users.AddAsync(user);
            await _unitOfWork.CompleteAsync();
        }
        public async Task AddNewOrder(int _ID_User)
        {
            var order = new Order
            {
                ID_User = _ID_User,
                Date = DateTime.Now,
                Status = "Обработка",
                DeliveryAddress = "-"
            };
            
            await _unitOfWork.Orders.AddAsync(order);
            await _unitOfWork.CompleteAsync();
            User usercurrent = new User();
            usercurrent = await _unitOfWork.Users.GetByIdAsync(_ID_User);

            var orders = await _unitOfWork.Orders.GetAllAsync();
            var filtered = orders.Where(o => o.ID_User == _ID_User).Last();
            usercurrent.CurrentCart = filtered.ID_Order;
            await _unitOfWork.Users.UpdateAsync(usercurrent);
            await _unitOfWork.CompleteAsync();
        }
        public async Task AddNewAutor(string _name)
        {
            var autor = new Autor
            {
                Name = _name,
            };

            await _unitOfWork.Authors.AddAsync(autor);
            await _unitOfWork.CompleteAsync();
        }
        public async Task AddNewPubl(string _name,string _address = "")
        {
            var publ = new Publishing
            {
                Name = _name,
                Address = _address
            };

            await _unitOfWork.Publishings.AddAsync(publ);
            await _unitOfWork.CompleteAsync();
        }
    }
}
