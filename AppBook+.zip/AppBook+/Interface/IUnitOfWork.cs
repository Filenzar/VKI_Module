﻿using AppBook.Interface;
using AppBook.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppBook.Class
{
    interface IUnitOfWork : IDisposable
    {
        IGenericRepository<Autor> Authors { get; }
        IGenericRepository<Book> Books { get; }
        IGenericRepository<ContentsOrder> ContentsOrders { get; }
        IGenericRepository<Order> Orders { get; }
        IGenericRepository<Publishing> Publishings { get; }
        IGenericRepository<User> Users { get; }
        IGenericRepository<UserType> UserTypes { get; }

        Task<int> CompleteAsync();  // Сохранение изменений
    }
}
