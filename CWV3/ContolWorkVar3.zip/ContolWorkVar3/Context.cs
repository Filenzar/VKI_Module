﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContolWork
{
    internal class Context
    {
        private static readonly ObservableCollection<Request> _requests = [];
        private static readonly ObservableCollection<Master> _masters = [];
        public static ObservableCollection<Request> GetRequests() { return _requests; }
        public static ObservableCollection<Master> GetMasters() { return _masters; }

        public static void AddRequest(Request _request)
        {
            _requests.Add(_request);
        }

        public static void AddMaster(Master _master)
        {
            _masters.Add(_master);
        }
        public static void UpdateRequest(int _requestsNum, Request updatedOrder)
        {
            var existingOrder = _requests.FirstOrDefault(o => o.Num == _requestsNum);
            if (existingOrder != null)
            {
                existingOrder.Type = updatedOrder.Type;
                existingOrder.Desc = updatedOrder.Desc;
                existingOrder.Prior = updatedOrder.Prior;
                existingOrder.Status = updatedOrder.Status;
                existingOrder.Master = updatedOrder.Master;
                if (updatedOrder.Status== Status.Выполненно) existingOrder.EndDate = DateTime.Now;
            }
        }
        public static void DeleteRequest(int _requestNum)
        {
            var req = _requests.FirstOrDefault(o => o.Num == _requestNum);
            if (req != null)
            {
                _requests.Remove(req);
            }
        }
    }
}
