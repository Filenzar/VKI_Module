﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ContolWork
{
    /// <summary>
    /// Логика взаимодействия для EditForm.xaml
    /// </summary>
    public partial class EditForm : Window
    {
        public Request request;
        public ObservableCollection<Master> _allMaster;
        public EditForm(Request _request)
        {
            InitializeComponent();
            request = _request;
            StatusComboBox.ItemsSource = Enum.GetValues(typeof(Status));
            TypeComboBox.ItemsSource = Enum.GetValues(typeof(TypeWork));
            PriorComboBox.ItemsSource = Enum.GetValues(typeof(Prior));

            StatusComboBox.SelectedItem = request.Status;
            TypeComboBox.SelectedItem = request.Type;
            PriorComboBox.SelectedItem = request.Prior;
            DescText.Text = request.Desc;

            _allMaster = Context.GetMasters();
            MasterComboBox.ItemsSource = _allMaster;
            MasterComboBox.DisplayMemberPath = "name";
            MasterComboBox.SelectedValuePath = "name";  
            MasterComboBox.SelectedItem = request.Master;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var newreq = new Request
            {
                Num = request.Num,
                Type = (TypeWork)TypeComboBox.SelectedItem,
                Desc = DescText.Text,
                AddDate = request.AddDate,
                Prior = (Prior)PriorComboBox.SelectedItem,
                Status = (Status)StatusComboBox.SelectedItem,
                Master = (Master)MasterComboBox.SelectedItem
            };
            Context.UpdateRequest(request.Num, newreq);
            MessageBox.Show("Заказ изменён");
            MainWindow.MainDataGride.Items.Refresh();
            this.Close();
        }
    }
}
