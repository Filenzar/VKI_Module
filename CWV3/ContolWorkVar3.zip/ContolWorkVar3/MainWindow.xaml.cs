﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ContolWork
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static DataGrid MainDataGride { get; private set; }
        public int count = 1;
        private ObservableCollection<Request> _allRequests;
        public ObservableCollection<Master> _allMaster;

        private ICollectionView _collectionView;
        public MainWindow()
        {
            InitializeComponent();
            _allRequests = Context.GetRequests();
            _allMaster = Context.GetMasters();
            _collectionView = CollectionViewSource.GetDefaultView(_allRequests);
            DataGrid.ItemsSource = _collectionView;
            StatusComboBox.ItemsSource = Enum.GetValues(typeof(Status));
            TypeSearchComboBox.ItemsSource = Enum.GetValues(typeof(TypeWork));
            TypeComboBox.ItemsSource = Enum.GetValues(typeof(TypeWork));
            PriorComboBox.ItemsSource = Enum.GetValues(typeof(Prior));
            var mast = new Master { num = 1, name = "Владимир Ничипаренко" };
            Context.AddMaster( mast );
            mast = new Master { num = 2, name = "Денис Закусило" };
            Context.AddMaster(mast);
            MasterComboBox.ItemsSource = _allMaster;
            MasterComboBox.DisplayMemberPath = "name";
            MasterComboBox.SelectedValuePath = "name";

            MainDataGride = DataGrid;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var newreq = new Request
            {
                Num = count,
                NumHome = Convert.ToInt32(HomeBox.Text),
                Type = (TypeWork)TypeComboBox.SelectedItem,
                Desc = DescText.Text,
                Prior = (Prior)PriorComboBox.SelectedItem,
                AddDate = DateTime.Now,
                Status = (Status)StatusComboBox.SelectedItem,
                Master = (Master)MasterComboBox.SelectedItem
            };
            Context.AddRequest(newreq);
            MessageBox.Show("Заказ добавлен");
            count++;
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataGrid.SelectedItem is Request selectedRequest)
            {
                var frm = new EditForm(selectedRequest);
                frm.ShowDialog();
            }
            
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TypeSearchComboBox.SelectedItem = null; 
            SearchTextBox.Text = null;
            _collectionView.Filter = null;
        }
        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string searchText = SearchTextBox.Text.ToLower();

            _collectionView.Filter = item =>
            {
                var _request = item as Request;
                return _request.NumHome.ToString().Contains(searchText);
            };
        }
        private void FilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_collectionView == null) return;

            // Применение фильтра в зависимости от выбранного элемента
            _collectionView.Filter = item =>
            {
                var _request = item as Request;

                switch (TypeSearchComboBox.SelectedIndex)
                {
                    case 0: // Все
                        return _request.Type == TypeWork.Сантехника;
                    case 1: // Молодые (до 30)
                        return _request.Type == TypeWork.Электроника;
                    case 2: // Взрослые (30 и старше)
                        return _request.Type == TypeWork.Косметичиский;
                    default:
                        return false;
                }
            };
        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataGrid.SelectedItem is Request selectedRequest)
            {
                var result = MessageBox.Show("Вы хотите удалить заказ?", "Подтверждение удаления", MessageBoxButton.YesNo);
                if (result == MessageBoxResult.Yes)
                {
                    Context.DeleteRequest(selectedRequest.Num);
                }
            }
        }

    }
}