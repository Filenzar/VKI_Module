﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContolWork
{
    public class Request
    {

        public int Num {  get; set; }
        public int NumHome { get; set; }
        public TypeWork Type { get; set; }
        public string Desc { get; set; }
        public Prior Prior { get; set; }
        public DateTime AddDate { get; set; }
        public DateTime EndDate { get; set; }
        public Status Status { get; set; }
        public Master Master { get; set; }
    }
}
