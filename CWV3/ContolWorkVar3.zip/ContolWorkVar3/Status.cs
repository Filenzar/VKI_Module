﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContolWork
{
    public enum Status
    {
        Новая,
        В_процессе,
        Выполненно
    }
}
