﻿using AppBook.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Configuration;

namespace AppBook.Class
{
    class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Autor> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<ContentsOrder> ContentsOrders { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<Publishing> Publishings { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            optionsBuilder.UseSqlServer(connectionString); // Укажите строку подключения к базе данных
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Autor>()
                .ToTable("Autors");
            modelBuilder.Entity<Book>()
                .ToTable("Book");
            modelBuilder.Entity<ContentsOrder>()
                .ToTable("ContentsOrder");
            modelBuilder.Entity<Order>()
                .ToTable("Order");
            modelBuilder.Entity<Publishing>()
                .ToTable("Publishing");
            modelBuilder.Entity<User>()
                .ToTable("Users");
            modelBuilder.Entity<UserType>()
                .ToTable("User_type");

            // Настройка связей (если нужно)
            modelBuilder.Entity<Book>()
                .HasOne(b => b.Author)
                .WithMany(a => a.Books)
                .HasForeignKey(b => b.ID_Autor);
            modelBuilder.Entity<Book>()
                .HasOne(b => b.Publishing)
                .WithMany(p => p.Books)
                .HasForeignKey(b => b.ID_Publishing);

            modelBuilder.Entity<ContentsOrder>()
                .HasKey(co => co.ID_Contents);

            modelBuilder.Entity<ContentsOrder>()
                .HasOne(co => co.Book)
                .WithMany(b => b.ContentsOrders)
                .HasForeignKey(co => co.ID_Book);

            modelBuilder.Entity<ContentsOrder>()
                .HasOne(co => co.Order)
                .WithMany(o => o.ContentsOrders)
                .HasForeignKey(co => co.ID_Order);

            modelBuilder.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.ID_User);

            modelBuilder.Entity<User>()
                .HasOne(o => o.UserType)
                .WithMany(u => u.Users)
                .HasForeignKey(o => o.ID_Type);

            modelBuilder.Entity<User>()
                .HasOne(o => o.Order)
                .WithMany(u => u.Users)
                .HasForeignKey(o => o.CurrentCart);

            // Триггеры

            modelBuilder.Entity<ContentsOrder>()
                .ToTable(tb => tb.HasTrigger("update_order_price_after_change"));
            modelBuilder.Entity<ContentsOrder>()
                .ToTable(tb => tb.HasTrigger("update_order_price_after_delete"));
            modelBuilder.Entity<ContentsOrder>()
                .ToTable(tb => tb.HasTrigger("update_order_price_after_id_order_change"));
            modelBuilder.Entity<ContentsOrder>()
                .ToTable(tb => tb.HasTrigger("update_order_price_after_insert"));


        }
}
}
