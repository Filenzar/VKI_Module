﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для UserForm.xaml
    /// </summary>
    public partial class UserForm : Window
    {
        private static UserForm _instance;
        private User usercurrent = new User();
        private readonly IUnitOfWork _unitOfWork;
        internal UserForm(User user)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            usercurrent = user;
            StackInfo.DataContext = usercurrent;
        }

        internal static UserForm GetInstance(User user)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new UserForm(user);
            }
            return _instance;
        }
        private void Orders_Click(object sender, RoutedEventArgs e)
        {
            OrdersForm order = OrdersForm.GetInstance(usercurrent);
            order.Show();
        }
    }
}
