﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using static System.Reflection.Metadata.BlobBuilder;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для AllOrdersForm.xaml
    /// </summary>
    public partial class AllOrdersForm : Window
    {
        private static AllOrdersForm _instance;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        public AllOrdersForm()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
            LoadProducts();
        }
        internal static AllOrdersForm GetInstance()
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new AllOrdersForm();
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var orders = await _unitOfWork.Orders.GetAllAsync();
            var filtered = orders.Where(b => b.Status != "Обработка");
            foreach (var order in filtered)
            {
                order.User = await _unitOfWork.Users.GetByIdAsync((int)order.ID_User);
            }
            OrdertListView.ItemsSource = filtered;
        }
        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idOrder = clickedButton.Tag;
                var info = new OrderInfo((int)idOrder);
                info.Show();
                // Здесь вы можете использовать idContents для удаления или других операций
                //MessageBox.Show($"Удалить элемент с ID: {idContents}");
            }
        }
        private async void DelivButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idOrder = clickedButton.Tag;
                var order = await _unitOfWork.Orders.GetByIdAsync((int)idOrder);
                order.Status = "Доставлено";
                await _unitOfWork.Orders.UpdateAsync(order);
                await _unitOfWork.CompleteAsync();
                LoadProducts();

                MessageBox.Show($"Статус изменен");
            }
        }
        private async void Deliv2Button_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;

            if (clickedButton != null)
            {
                // Получаем значение Tag из кнопки
                var idOrder = clickedButton.Tag;
                var order = await _unitOfWork.Orders.GetByIdAsync((int)idOrder);
                order.Status = "В пути";
                await _unitOfWork.Orders.UpdateAsync(order);
                await _unitOfWork.CompleteAsync();
                LoadProducts();

                MessageBox.Show($"Статус изменен");
            }
        }
    }
}
