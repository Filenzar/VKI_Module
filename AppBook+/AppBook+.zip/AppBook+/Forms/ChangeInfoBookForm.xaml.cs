﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;


namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для ChangeInfoBookForm.xaml
    /// </summary>
    public partial class ChangeInfoBookForm : Window
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        private int _currentBook;
        private static ChangeInfoBookForm _instance;

        private AllBookForm _bookForm;

        public ChangeInfoBookForm(int currentBook,AllBookForm _bookForm)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
            LoadProducts();
            this._currentBook = currentBook;
            this._bookForm = _bookForm;
        }
        internal static ChangeInfoBookForm GetInstance(int currentBook, AllBookForm _bookForm)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new ChangeInfoBookForm(currentBook, _bookForm);
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var autors = await _unitOfWork.Authors.GetAllAsync();
            ComboBoxAutors.ItemsSource = autors; // Привязка данных к ComboBox
            ComboBoxAutors.DisplayMemberPath = "Name"; // Отображаемое свойство
            ComboBoxAutors.SelectedValuePath = "ID_Autor";

            var publ = await _unitOfWork.Publishings.GetAllAsync();
            ComboBoxPublish.ItemsSource = publ; // Привязка данных к ComboBox
            ComboBoxPublish.DisplayMemberPath = "Name"; // Отображаемое свойство
            ComboBoxPublish.SelectedValuePath = "ID_Publishing";
            
            var book = await _unitOfWork.Books.GetByIdAsync(_currentBook);
            book.Author = await _unitOfWork.Authors.GetByIdAsync((int)book.ID_Autor);
            book.Publishing = await _unitOfWork.Publishings.GetByIdAsync((int)book.ID_Publishing);


            ComboBoxPublish.SelectedValue = book.ID_Publishing;
            ComboBoxAutors.SelectedValue = book.ID_Autor;
            Name.Text = book.Name;
            Age.Text = book.Age.ToString();
            Pages.Text = book.Pages.ToString();
            Year.Text = book.Year.ToString();
            Copies.Text = book.Copies.ToString();
            Price.Text = book.Price.ToString();
        }
        private async void ChangeButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                var book = await _unitOfWork.Books.GetByIdAsync(_currentBook);
                book.Name = Name.Text;
                book.ID_Autor = (int)ComboBoxAutors.SelectedValue;
                book.ID_Publishing = (int)ComboBoxPublish.SelectedValue;
                book.Age = int.Parse(Age.Text);
                book.Pages = int.Parse(Pages.Text);
                book.Year = int.Parse(Year.Text);
                book.Copies = int.Parse(Copies.Text);
                book.Price = decimal.Parse(Price.Text);
                await _unitOfWork.Books.UpdateAsync(book);
                await _unitOfWork.CompleteAsync();

                _bookForm.Close();
                var inf = AllBookForm.GetInstance();

                inf.Show();
                this.Close();
            }
        }

        //private void CancelButton_Click(object sender, RoutedEventArgs e)
        //{
        //    Button clickedButton = sender as Button;
        //    if (clickedButton != null)
        //    {
        //        var allb = AllBookForm.GetInstance();
        //        allb.Show();
        //        this.Close();
        //    }
        //}
    }
}
