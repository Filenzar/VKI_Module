﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;


namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для AddPublForm.xaml
    /// </summary>
    public partial class AddPublForm : Window
    {
        private static AddPublForm _instance;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;
        public AddPublForm()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
        }
        internal static AddPublForm GetInstance()
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new AddPublForm();
            }
            return _instance;
        }
        private async void AddPublButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (Name.Text != "")
                {
                    await _serviceAdd.AddNewPubl(Name.Text);
                    MessageBox.Show($"Издатель успешно добавлен", "Добавление издателя");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Пожалуйста, заполните все поля.");
                }

            }
        }
    }
}
