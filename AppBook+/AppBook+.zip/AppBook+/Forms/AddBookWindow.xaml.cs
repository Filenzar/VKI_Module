﻿using AppBook.Class;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using AppBook.Model;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для BookWindow.xaml
    /// </summary>
    public partial class BookWindow : Window
    {
        private static BookWindow _instance;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ServiceAdd _serviceAdd;

        private AllBookForm _bookForm;

        public BookWindow(AllBookForm bookForm)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));
            _serviceAdd = new ServiceAdd(_unitOfWork);
            this._bookForm = bookForm;
            LoadProducts();
        }
        internal static BookWindow GetInstance(AllBookForm bookForm)
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new BookWindow(bookForm);
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var autors = await _unitOfWork.Authors.GetAllAsync();
            ComboBoxAutors.ItemsSource = autors; // Привязка данных к ComboBox
            ComboBoxAutors.DisplayMemberPath = "Name"; // Отображаемое свойство
            ComboBoxAutors.SelectedValuePath = "ID_Autor";

            var publ = await _unitOfWork.Publishings.GetAllAsync();
            ComboBoxPublish.ItemsSource = publ; // Привязка данных к ComboBox
            ComboBoxPublish.DisplayMemberPath = "Name"; // Отображаемое свойство
            ComboBoxPublish.SelectedValuePath = "ID_Publishing";
        }
        private async void AddBookButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                if (Name.Text != "" &&
                    ComboBoxAutors.SelectedItem != null &&
                    ComboBoxPublish.SelectedItem != null &&
                    Age.Text != "" &&
                    Pages.Text != "" &&
                    Year.Text != "" &&
                    Copies.Text != "" &&
                    Price.Text != "")
                {
                    if ((ComboBoxAutors.SelectedItem is Autor selectedAutor) && (ComboBoxPublish.SelectedItem is Publishing selectedpublishing))
                    {
                        int selectedAutorId = selectedAutor.ID_Autor;
                        int selectedpubId = selectedpublishing.ID_Publishing;
                        //MessageBox.Show($"ComboBoxAutors: {selectedAutorId} ComboBoxAutors: {selectedpubId}");
                        await _serviceAdd.AddNewBook(Name.Text, selectedAutorId, selectedpubId, int.Parse(Price.Text), int.Parse(Year.Text), int.Parse(Age.Text), int.Parse(Copies.Text), int.Parse(Pages.Text));
                        MessageBox.Show($"Книга успешна добавлена","Добавление книги");
                        _bookForm.Close();
                        var allb = AllBookForm.GetInstance();
                        allb.Show();
                        this.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста, заполните все поля.");
                }

            }
        }
    }
}
