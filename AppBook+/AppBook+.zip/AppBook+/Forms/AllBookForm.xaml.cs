﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace AppBook.Forms
{
    /// <summary>
    /// Логика взаимодействия для AllBookForm.xaml
    /// </summary>
    public partial class AllBookForm : Window
    {
        private static AllBookForm _instance;
        private readonly IUnitOfWork _unitOfWork;

        public AllBookForm()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));

            LoadProducts();
        }
        internal static AllBookForm GetInstance()
        {
            if (_instance == null || !_instance.IsVisible)
            {
                _instance = new AllBookForm();
            }
            return _instance;
        }
        private async void LoadProducts()
        {
            var books = await _unitOfWork.Books.GetAllAsync();
            foreach (var book in books)
            {
                book.Author = await _unitOfWork.Authors.GetByIdAsync((int)book.ID_Autor);
                book.Publishing = await _unitOfWork.Publishings.GetByIdAsync((int)book.ID_Publishing);
            }

            ProductListView.ItemsSource = books;

        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                var inf = BookWindow.GetInstance(this);
                inf.Show();
            }
        }
        private void AddAutorButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                var aut = AddAutorForm.GetInstance();
                aut.Show();
            }
        }
        private void AddPublButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                var pub = AddPublForm.GetInstance();
                pub.Show();
            }
        }
        private void InfoButton_Click(object sender, RoutedEventArgs e)
        {
            Button clickedButton = sender as Button;
            if (clickedButton != null)
            {
                var inf = ChangeInfoBookForm.GetInstance((int)clickedButton.Tag,this);
                inf.Show();
            }
        }
    }
}
