﻿using AppBook.Class;
using AppBook.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;


namespace AppBook
{
    /// <summary>
    /// Логика взаимодействия для OrderInfo.xaml
    /// </summary>
    public partial class OrderInfo : Window
    {
        private int currentOrder;
        private readonly IUnitOfWork _unitOfWork;
        public OrderInfo(int currentOrder)
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlServer(connectionString) // Укажите строку подключения к базе данных
                .Options;

            _unitOfWork = new UnitOfWork(new AppDbContext(options));

            this.currentOrder = currentOrder;
            LoadProducts();
        }
        private async void LoadProducts()
        {
            var content = await _unitOfWork.ContentsOrders.GetAllAsync();
            var _filter2 = content.Where(b => b.ID_Order == currentOrder);
            foreach (var cntt in _filter2)
            {
                cntt.Book = await _unitOfWork.Books.GetByIdAsync((int)cntt.ID_Book);
            }

            ProductListView.ItemsSource = _filter2;
        }
    }
}
