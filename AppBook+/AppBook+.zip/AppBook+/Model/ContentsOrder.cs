﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace AppBook.Model
{
    class ContentsOrder
    {
        [Key]
        public int ID_Contents { get; set; }
        public int? ID_Order { get; set; }
        public int? ID_Book { get; set; }
        public int Count { get; set; }

        public Book Book { get; set; }
        public Order Order { get; set; }
    }
}
