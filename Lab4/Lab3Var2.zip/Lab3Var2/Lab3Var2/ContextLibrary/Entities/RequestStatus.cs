﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Var2.ContextLibrary.Entities
{
    /// <summary>
    /// Статус заявки
    /// </summary>
    public enum RequestStatus
    {
        /// <summary>
        /// Ожидание
        /// </summary>
        Expectation,

        /// <summary>
        /// В процессе
        /// </summary>
        InProgress
,

        /// <summary>
        /// Готово
        /// </summary>
        Done
    }
}
