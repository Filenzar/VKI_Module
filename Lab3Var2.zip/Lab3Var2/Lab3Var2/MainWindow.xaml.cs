﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ContextLibrary.Entities;
using ContextLibrary;

namespace Lab3Var2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
            RequestsListView.ItemsSource = ContextLibrary.ApplicationContext.GetRequests();
            ProductTypeComboBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.Type));
            ProductTypeComboBox.SelectedIndex = 0;
        }
        public int count = ApplicationContext.GetRequests().Count;
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newRequest = new Request
                {
                    Number = count + 1 , // Генерация номера заказа
                    AddedDate = DateTime.Now,
                    ProductType = (ContextLibrary.Entities.Type)ProductTypeComboBox.SelectedItem,
                    Model = Model.Text,
                    Description = Desc.Text,
                    CustomerFullName = CustomerNameTextBox.Text,
                    CustomerPhone = CustomerPhoneTextBox.Text,
                    Status = RequestStatus.Expectation // Начальный статус
                };

                ApplicationContext.AddRequest(newRequest);
                MessageBox.Show("Заказ успешно добавлен!");
                count++;
                Model.Text = null;
                Desc.Text = null;
                CustomerNameTextBox.Text = null;
                CustomerPhoneTextBox.Text = null;
            }
            catch
            {
                MessageBox.Show("Неправельное заполнение", "Ошибка");
            }
        }
        private void EditOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var editOrderWindow = new EditRequestWindow(selectedRequest);
                editOrderWindow.ShowDialog();
            }
        }
        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить заказ?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    ApplicationContext.DeleteRequest(selectedRequest.Number);
                }
            }
        }
    }
}