﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContextLibrary.Entities
{
    /// <summary>
    /// Вид товара (классификация Европейской экономической комиссии)
    /// </summary>
    public enum Type
    {

        Fridge,

        WashingMachine,

        TV,

        Phone
    }

}
