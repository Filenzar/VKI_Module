﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContextLibrary.Entities
{
    /// <summary>
    /// Статус заявки
    /// </summary>
    public enum RequestStatus
    {
        /// <summary>
        /// Ожидание
        /// </summary>
        Expectation,

        /// <summary>
        /// В процессе
        /// </summary>
        InProgress
,

        /// <summary>
        /// Готово
        /// </summary>
        Done
    }
}
