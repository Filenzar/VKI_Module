﻿using ContextLibrary.Entities;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace ContextLibrary
{
    public class ApplicationContext : IDisposable
    {
        private bool _isDisposed = false;
        private static readonly ObservableCollection<Request> requests = [];

        public ObservableCollection<Request> Requests { get => requests; }
        public static ObservableCollection<Request> GetRequests()
        {
            return requests;
        }

        public static void AddRequest(Request request)
        {
            requests.Add(request);
        }
        public static void UpdateRequest(int requestNumber, Request updatedOrder)
        {
            var existingOrder = requests.FirstOrDefault(o => o.Number == requestNumber);
            if (existingOrder != null)
            {
                existingOrder.ProductType = updatedOrder.ProductType;
                existingOrder.Description = updatedOrder.Description;
                existingOrder.CustomerFullName = updatedOrder.CustomerFullName;
                existingOrder.CustomerPhone = updatedOrder.CustomerPhone;
                existingOrder.Status = updatedOrder.Status;
            }
        }
        public static void DeleteRequest(int requestNumber)
        {
            var order = requests.FirstOrDefault(o => o.Number == requestNumber);
            if (order != null)
            {
                requests.Remove(order);
            }
        }
        protected virtual void Dispose(bool disposing)
        {
            // check if already disposed 
            if (!_isDisposed)
            {
                // set the bool value to true 
                _isDisposed = true;
            }
        }
        public void Dispose()
        {
            // Invoke the above virtual 
            // dispose(bool disposing) method 
            Dispose(disposing: true);

            // Notify the garbage collector 
            // about the cleaning event 
            GC.SuppressFinalize(this);
        }
    }
}
