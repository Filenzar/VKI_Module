﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ContextLibrary;
using ContextLibrary.Entities;

namespace Lab3Var2
{
    /// <summary>
    /// Логика взаимодействия для EditRequestWindow.xaml
    /// </summary>
    public partial class EditRequestWindow : Window
    {
        public Request Request;
        public EditRequestWindow(Request request)
        {
            InitializeComponent();
            this.Request = request;
            typeBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.Type));
            typeBox.SelectedItem = request.ProductType;
            Status.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.RequestStatus));
            Status.SelectedItem = request.Status;
            descBox.Text = request.Description.ToString();
            modelBox.Text = request.Model.ToString();
            CustomerNameTextBox.Text = request.CustomerFullName;
            CustomerPhoneTextBox.Text = request.CustomerPhone;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var newRequest = new Request
                {
                    Number = Request.Number, // Генерация номера заказа
                    AddedDate = Request.AddedDate.Date,
                    ProductType = (ContextLibrary.Entities.Type)typeBox.SelectedItem,
                    Model = modelBox.Text,
                    Description = descBox.Text,
                    CustomerFullName = CustomerNameTextBox.Text,
                    CustomerPhone = CustomerPhoneTextBox.Text,
                    Status = (ContextLibrary.Entities.RequestStatus)Status.SelectedItem // Начальный статус
                };

                ApplicationContext.UpdateRequest(Request.Number, newRequest);
                MessageBox.Show("Заказ успешно обновлен!");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Неправельное заполнение", "Ошибка");
            }
        }
    }
}
