﻿using ContextLibrary;
using ContextLibrary.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab2Var5
{
    /// <summary>
    /// Логика взаимодействия для EditRequestWindow.xaml
    /// </summary>
    public partial class EditRequestWindow : Window
    {
        public Request Request;
        public EditRequestWindow(Request request)
        {
            InitializeComponent();
            this.Request = request;
            ProductTypeComboBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.Type));
            ProductTypeComboBox.SelectedItem = request.ProductType;
            Status.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.RequestStatus));
            Status.SelectedItem = request.Status;
            ProductWeightTextBox.Text = request.ProductWeight.ToString();
            ProductVolumeTextBox.Text = request.ProductVolume.ToString();
            DistanceTextBox.Text = request.Distance.ToString();
            QuantityTextBox.Text = request.Quantity.ToString();
            CustomerNameTextBox.Text = request.CustomerFullName;
            CustomerPhoneTextBox.Text = request.CustomerPhone;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var newRequest = new Request
            {
                Number = Request.Number,
                AddedDate = Request.AddedDate.Date,
                ProductType = (ContextLibrary.Entities.Type)ProductTypeComboBox.SelectedItem,
                ProductWeight = Convert.ToDouble(ProductWeightTextBox.Text),
                ProductVolume = Convert.ToDouble(ProductVolumeTextBox.Text),
                Distance = Convert.ToDouble(DistanceTextBox.Text),
                Quantity = Convert.ToInt32(QuantityTextBox.Text),
                CustomerFullName = CustomerNameTextBox.Text,
                CustomerPhone = CustomerPhoneTextBox.Text,
                Status = (ContextLibrary.Entities.RequestStatus)Status.SelectedItem // Начальный статус
            };

            ApplicationContext.UpdateOrder(Request.Number,newRequest);
            MessageBox.Show("Заказ успешно обновлен!");
            this.Close();
        }
    }
}
