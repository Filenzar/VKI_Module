﻿using ContextLibrary;
using ContextLibrary.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab2Var5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            RequestsListView.ItemsSource = ApplicationContext.GetRequests();
        }
        private void AddOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var addOrderWindow = new AddRequestWindow();
            addOrderWindow.ShowDialog();
        }

        private void EditOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var editOrderWindow = new EditRequestWindow(selectedRequest);
                editOrderWindow.ShowDialog();
            }
        }

        private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
        {
            if (RequestsListView.SelectedItem is Request selectedRequest)
            {
                var result = MessageBox.Show("Вы уверены, что хотите удалить заказ?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes) 
                {
                    ApplicationContext.DeleteOrder(selectedRequest.Number);
                }
            }
        }
    }
}