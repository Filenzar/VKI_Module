﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContextLibrary.Entities
{
    /// <summary>
    /// Вид товара (классификация Европейской экономической комиссии)
    /// </summary>
    public enum Type
    {
        /// <summary>
        /// Продукты питания
        /// </summary>
        Food,
        /// <summary>
        /// Одежда
        /// </summary>
        Clothing,
        /// <summary>
        /// Электроника
        /// </summary>
        Electronics,
        /// <summary>
        /// Бытовая техника
        /// </summary>
        HomeAppliances,
        /// <summary>
        /// Косметика и парфюмерия
        /// </summary>
        Cosmetics,
        /// <summary>
        /// Игрушки
        /// </summary>
        Toys,
        /// <summary>
        /// Спортивное оборудование
        /// </summary>
        SportsEquipment,
        /// <summary>
        /// Книги
        /// </summary>
        Books,
        /// <summary>
        /// Мебель
        /// </summary>
        Furniture,
        /// <summary>
        /// Аксессуары
        /// </summary>
        Accessories
    }

}
