﻿using System.ComponentModel;

namespace ContextLibrary.Entities
{
    /// <summary>
    /// Сущность "Заявка"
    /// </summary>
    public class Request : INotifyPropertyChanged
    {
        private int _number;
        public DateTime AddedDate { get; set; }
        private Type _productType;
        private double _productWeight;
        private double _productVolume;
        private double _distance;
        private int _quantity;
        private string _customerFullName;
        private string _customerPhone;
        private RequestStatus _status;

        public int Number
        {
            get => _number;
            set
            {
                _number = value;
                OnPropertyChanged(nameof(Number));
            }
        }

        public Type ProductType
        {
            get => _productType;
            set
            {
                _productType = value;
                OnPropertyChanged(nameof(ProductType));
            }
        }

        public double ProductWeight
        {
            get => _productWeight;
            set
            {
                _productWeight = value;
                OnPropertyChanged(nameof(ProductWeight));
            }
        }

        public double ProductVolume
        {
            get => _productVolume;
            set
            {
                _productVolume = value;
                OnPropertyChanged(nameof(ProductVolume));
            }
        }

        public double Distance
        {
            get => _distance;
            set
            {
                _distance = value;
                OnPropertyChanged(nameof(Distance));
            }
        }

        public int Quantity
        {
            get => _quantity;
            set
            {
                _quantity = value;
                OnPropertyChanged(nameof(Quantity));
            }
        }

        public string CustomerFullName
        {
            get => _customerFullName;
            set
            {
                _customerFullName = value;
                OnPropertyChanged(nameof(CustomerFullName));
            }
        }

        public string CustomerPhone
        {
            get => _customerPhone;
            set
            {
                _customerPhone = value;
                OnPropertyChanged(nameof(CustomerPhone));
            }
        }

        public RequestStatus Status
        {
            get => _status;
            set
            {
                _status = value;
                OnPropertyChanged(nameof(Status));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
