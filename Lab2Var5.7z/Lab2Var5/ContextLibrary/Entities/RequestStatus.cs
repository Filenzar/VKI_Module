﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContextLibrary.Entities
{
    /// <summary>
    /// Статус заявки
    /// </summary>
    public enum RequestStatus
    {
        /// <summary>
        /// В пути
        /// </summary>
        InTransit,

        /// <summary>
        /// На складе
        /// </summary>
        InWarehouse,

        /// <summary>
        /// Доставлен
        /// </summary>
        Delivered
    }
}
