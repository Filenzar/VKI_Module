﻿using ContextLibrary;
using ContextLibrary.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab2Var5
{
    /// <summary>
    /// Логика взаимодействия для AddRequestWindow.xaml
    /// </summary>
    public partial class AddRequestWindow : Window
    {
        public AddRequestWindow()
        {
            InitializeComponent();
            ProductTypeComboBox.ItemsSource = Enum.GetValues(typeof(ContextLibrary.Entities.Type));
            ProductTypeComboBox.SelectedIndex = 0;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var newRequest = new Request
            {
                Number = ApplicationContext.GetRequests().Count + 1, // Генерация номера заказа
                AddedDate = DateTime.Now,
                ProductType = (ContextLibrary.Entities.Type)ProductTypeComboBox.SelectedItem,
                ProductWeight = Convert.ToDouble(ProductWeightTextBox.Text),
                ProductVolume = Convert.ToDouble(ProductVolumeTextBox.Text),
                Distance = Convert.ToDouble(DistanceTextBox.Text),
                Quantity = Convert.ToInt32(QuantityTextBox.Text),
                CustomerFullName = CustomerNameTextBox.Text,
                CustomerPhone = CustomerPhoneTextBox.Text,
                Status = RequestStatus.InWarehouse // Начальный статус
            };

            ApplicationContext.AddRequest(newRequest);
            MessageBox.Show("Заказ успешно добавлен!");
            this.Close();
        }
    }
}
